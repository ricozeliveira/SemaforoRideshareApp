
package com.semaforo.ridehud
data class RideSnapshot(
    val valor: Double,
    val kmViagem: Double,
    val kmPickup: Double,
    val minutosTotais: Int
)
