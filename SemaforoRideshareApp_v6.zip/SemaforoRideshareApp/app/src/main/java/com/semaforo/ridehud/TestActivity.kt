
package com.semaforo.ridehud

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.widget.Button
import androidx.appcompat.app.AppCompatActivity

class TestActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_test)

        findViewById<Button>(R.id.btnConfig).setOnClickListener {
            startActivity(Intent(this, SettingsActivity::class.java))
        }

        if (!Settings.canDrawOverlays(this)) {
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
        }

        findViewById<Button>(R.id.btnTestVerde).setOnClickListener {
            RideOverlay.init(this)
            RideOverlay.updateWith(RideSnapshot(valor=18.0, kmViagem=6.0, kmPickup=0.8, minutosTotais=18))
        }
        findViewById<Button>(R.id.btnTestAmarelo).setOnClickListener {
            RideOverlay.init(this)
            RideOverlay.updateWith(RideSnapshot(valor=14.0, kmViagem=7.0, kmPickup=1.0, minutosTotais=24))
        }
        findViewById<Button>(R.id.btnTestVermelho).setOnClickListener {
            RideOverlay.init(this)
            RideOverlay.updateWith(RideSnapshot(valor=9.0, kmViagem=8.0, kmPickup=2.0, minutosTotais=25))
        }
    }
}
