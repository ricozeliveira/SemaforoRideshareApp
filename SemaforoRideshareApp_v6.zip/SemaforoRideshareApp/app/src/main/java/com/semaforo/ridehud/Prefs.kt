
package com.semaforo.ridehud

import android.content.Context

object Prefs {
    private const val FILE = "ridehud_prefs"
    private const val K_CUSTO_KM = "custo_km"
    private const val K_PK_GREEN = "pk_green"
    private const val K_PK_AMBER = "pk_amber"
    private const val K_HR_GREEN = "hr_green"
    private const val K_HR_AMBER = "hr_amber"

    private const val D_CUSTO_KM = 1.13
    private const val D_PK_GREEN = 1.50
    private const val D_PK_AMBER = 1.30
    private const val D_HR_GREEN = 24.0
    private const val D_HR_AMBER = 20.0

    fun getCustoKm(ctx: Context) = ctx.getSharedPreferences(FILE, 0).getFloat(K_CUSTO_KM, D_CUSTO_KM.toFloat()).toDouble()
    fun getPkGreen(ctx: Context) = ctx.getSharedPreferences(FILE, 0).getFloat(K_PK_GREEN, D_PK_GREEN.toFloat()).toDouble()
    fun getPkAmber(ctx: Context) = ctx.getSharedPreferences(FILE, 0).getFloat(K_PK_AMBER, D_PK_AMBER.toFloat()).toDouble()
    fun getHrGreen(ctx: Context) = ctx.getSharedPreferences(FILE, 0).getFloat(K_HR_GREEN, D_HR_GREEN.toFloat()).toDouble()
    fun getHrAmber(ctx: Context) = ctx.getSharedPreferences(FILE, 0).getFloat(K_HR_AMBER, D_HR_AMBER.toFloat()).toDouble()

    fun saveAll(ctx: Context, custoKm: Double, pkGreen: Double, pkAmber: Double, hrGreen: Double, hrAmber: Double) {
        ctx.getSharedPreferences(FILE, 0).edit()
            .putFloat(K_CUSTO_KM, custoKm.toFloat())
            .putFloat(K_PK_GREEN, pkGreen.toFloat())
            .putFloat(K_PK_AMBER, pkAmber.toFloat())
            .putFloat(K_HR_GREEN, hrGreen.toFloat())
            .putFloat(K_HR_AMBER, hrAmber.toFloat())
            .apply()
    }
}
