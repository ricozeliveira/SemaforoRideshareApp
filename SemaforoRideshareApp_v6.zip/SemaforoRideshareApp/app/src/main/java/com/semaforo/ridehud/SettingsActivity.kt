
package com.semaforo.ridehud

import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity

class SettingsActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_settings)

        val inCustoKm = findViewById<EditText>(R.id.inCustoKm)
        val inPkGreen = findViewById<EditText>(R.id.inPkGreen)
        val inPkAmber = findViewById<EditText>(R.id.inPkAmber)
        val inHrGreen = findViewById<EditText>(R.id.inHrGreen)
        val inHrAmber = findViewById<EditText>(R.id.inHrAmber)

        inCustoKm.setText(Prefs.getCustoKm(this).toString())
        inPkGreen.setText(Prefs.getPkGreen(this).toString())
        inPkAmber.setText(Prefs.getPkAmber(this).toString())
        inHrGreen.setText(Prefs.getHrGreen(this).toString())
        inHrAmber.setText(Prefs.getHrAmber(this).toString())

        findViewById<Button>(R.id.btnSalvar).setOnClickListener {
            try {
                val custoKm = inCustoKm.text.toString().replace(",", ".").toDouble()
                val pkGreen = inPkGreen.text.toString().replace(",", ".").toDouble()
                val pkAmber = inPkAmber.text.toString().replace(",", ".").toDouble()
                val hrGreen = inHrGreen.text.toString().replace(",", ".").toDouble()
                val hrAmber = inHrAmber.text.toString().replace(",", ".").toDouble()
                Prefs.saveAll(this, custoKm, pkGreen, pkAmber, hrGreen, hrAmber)
                Toast.makeText(this, "Configurações salvas!", Toast.LENGTH_SHORT).show()
            } catch (e: Exception) {
                Toast.makeText(this, "Verifique os valores digitados.", Toast.LENGTH_SHORT).show()
            }
        }

        findViewById<Button>(R.id.btnVoltar).setOnClickListener { finish() }
    }
}
