
package com.semaforo.ridehud

import android.content.Context
import android.graphics.Color
import android.graphics.PixelFormat
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.view.*
import android.widget.TextView

object RideOverlay {
    private lateinit var window: WindowManager
    private var view: View? = null

    fun init(ctx: Context) {
        if (this::window.isInitialized && view != null) return
        window = ctx.getSystemService(Context.WINDOW_SERVICE) as WindowManager
        view = LayoutInflater.from(ctx).inflate(R.layout.overlay_hud, null)
        val type = if (Build.VERSION.SDK_INT >= 26)
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        else WindowManager.LayoutParams.TYPE_PHONE
        val p = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            type,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                    WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        )
        p.gravity = Gravity.TOP or Gravity.CENTER_HORIZONTAL
        window.addView(view, p)
    }

    fun updateWith(s: RideSnapshot) {
        val totalKm = (s.kmViagem + s.kmPickup).coerceAtLeast(0.01)
        val rpkm = s.valor / totalKm
        val rph  = if (s.minutosTotais > 0) s.valor / (s.minutosTotais/60.0) else 0.0

        val custoKm = Prefs.getCustoKm(view!!.context)
        val margem = rpkm - custoKm

        val pkGreen = Prefs.getPkGreen(view!!.context)
        val pkAmber = Prefs.getPkAmber(view!!.context)
        val hrGreen = Prefs.getHrGreen(view!!.context)
        val hrAmber = Prefs.getHrAmber(view!!.context)

        val green = (rpkm >= pkGreen && rph >= hrGreen)
        val yellow = (!green && rpkm >= pkAmber && rph >= hrAmber)

        val color = when {
            green -> Color.parseColor("#10b981")
            yellow -> Color.parseColor("#f59e0b")
            else -> Color.parseColor("#ef4444")
        }

        view?.findViewById<TextView>(R.id.txtRpkm)?.text = "R$ %.2f/km".format(rpkm)
        view?.findViewById<TextView>(R.id.txtRph )?.text = "R$ %.2f/hr".format(rph)
        view?.findViewById<TextView>(R.id.txtMargem)?.text = "R$ %.2f".format(margem)
        view?.findViewById<View>(R.id.dot)?.background?.setTint(color)

        Handler(Looper.getMainLooper()).postDelayed({ try { hide() } catch (_:Exception) {} }, 6000)
    }

    fun hide() {
        try { view?.let { (window as WindowManager).removeView(it) } } catch (_:Exception) {}
        view = null
    }
}
