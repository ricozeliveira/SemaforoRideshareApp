
package com.semaforo.ridehud

import android.accessibilityservice.AccessibilityService
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo

class RideAccessibilityService : AccessibilityService() {

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        val root = rootInActiveWindow ?: return
        val snap = extractOffer(root)
        if (snap != null) {
            RideOverlay.updateWith(snap)
        }
    }
    override fun onInterrupt() {}

    private fun extractOffer(root: AccessibilityNodeInfo): RideSnapshot? {
        val texts = mutableListOf<String>()
        fun collect(n: AccessibilityNodeInfo?) {
            if (n == null) return
            n.text?.toString()?.let { if (it.isNotBlank()) texts.add(it) }
            for (i in 0 until n.childCount) collect(n.getChild(i))
        }
        collect(root)
        val all = texts.joinToString(" ")

        val priceRegex = Regex("R\$\s*\d{1,3}(\.\d{3})*,\d{2}")
        val kmRegex = Regex("(\d+[.,]\d+)\s*km")
        val minRegex = Regex("(\d+)\s*min")

        val price = priceRegex.find(all)?.value
        val kmMatches = kmRegex.findAll(all).toList()
        val min = minRegex.find(all)?.groupValues?.getOrNull(1)?.toIntOrNull() ?: 0

        if (price == null || kmMatches.isEmpty()) return null
        val valor = price.replace("R$", "").replace(".", "").replace(",", ".").trim().toDouble()
        val tripKm = kmMatches.last().groupValues[1].replace(",", ".").toDouble()
        val pickupKm = (kmMatches.firstOrNull()?.groupValues?.getOrNull(1) ?: "0").replace(",", ".").toDouble()

        return RideSnapshot(valor, tripKm, pickupKm, min)
    }
}
