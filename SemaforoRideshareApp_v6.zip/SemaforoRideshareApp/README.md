
# Semáforo RideHUD

Projeto Android com HUD flutuante para motoristas de aplicativo. Lê o card via Acessibilidade e calcula R$/km, R$/h e margem.

## Como gerar APK pelo GitHub
1. Suba esta pasta inteira para um repositório no GitHub.
2. Vá na aba **Actions** e aguarde o fluxo **Build APK** terminar.
3. Baixe o artefato **app-debug.apk**.

Se precisar rodar localmente, abra no Android Studio e use **Build APK(s)**.
